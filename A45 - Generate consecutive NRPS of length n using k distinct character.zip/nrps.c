#include <stdio.h>

void nrps(char [], int, int);

int main()
{
    //read the input from the user
    
    //function call to pass input to the function
    
}