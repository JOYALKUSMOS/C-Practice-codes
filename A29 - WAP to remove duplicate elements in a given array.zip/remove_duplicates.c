#include <stdio.h>

void fun(int arr1[], int size, int arr2[], int *new_size);

int main()
{
    
}