#include <stdio.h>
#include <stdlib.h>

#define SIZE 8

void add_element(void *memory, int *flags);
void remove_element(int *flags);
void display_elements(void *memory, int *flags);

int main() {
    void *memory = malloc(SIZE);
    int flags[SIZE] = {0};

    int choice;
    while (1) {
        printf("Menu:\n");
        printf("1. Add element\n");
        printf("2. Remove element\n");
        printf("3. Display element\n");
        printf("4. Exit from the program\n");
        printf("Choice ---> ");
        scanf("%d", &choice);
        switch (choice) {
            case 1:
                add_element(memory, flags);
                break;
            case 2:
                display_elements(memory, flags);
                remove_element(flags);
                break;
            case 3:
                display_elements(memory, flags);
                break;
            case 4:
                free(memory);
                exit(0);
            default:
                printf("Invalid choice! Please choose again.\n");
        }
    }
    return 0;
}

void add_element(void *memory, int *flags) {
    int type_choice;
    printf("Enter the type you have to insert:\n");
    printf("1. int\n2. char\n3. float\n4. double\nChoice ---> ");
    scanf("%d", &type_choice);
    switch (type_choice) {
        case 1: {
            if (flags[4] || flags[5] || flags[6] || flags[7]) {
                printf("Error: Not enough space to store an int.\n");
            } else {
                int value;
                printf("Enter the int: ");
                scanf("%d", &value);
                *(int *)((char *)memory + 4) = value;
                flags[4] = flags[5] = flags[6] = flags[7] = 1;
            }
            break;
        }
        case 2: {
            if (flags[0]) {
                printf("Error: Memory already contains a char at index 0.\n");
            } else {
                char value;
                printf("Enter the char: ");
                scanf(" %c", &value);
                *(char *)memory = value;
                flags[0] = 1;
            }
            break;
        }
        case 3: {
            if (flags[4] || flags[5] || flags[6] || flags[7]) {
                printf("Error: Not enough space to store a float.\n");
            } else {
                float value;
                printf("Enter the float: ");
                scanf("%f", &value);
                *(float *)((char *)memory + 4) = value; 
                flags[4] = flags[5] = flags[6] = flags[7] = 1;
            }
            break;
        }
        case 4: {
            if (flags[0] || flags[1] || flags[2] || flags[3]) {
                printf("Error: Not enough space to store a double.\n");
            } else {
                double value;
                printf("Enter the double: ");
                scanf("%lf", &value);
                *(double *)memory = value;
                flags[0] = flags[1] = flags[2] = flags[3] = 1;
            }
            break;
        }
        default:
            printf("Invalid type choice!\n");
    }
}

void display_elements(void *memory, int *flags) {
    printf("-------------------------\n");
    for (int i = 0; i < SIZE; i++) {
        if (flags[i]) {
            if (i == 0) {
                printf("%d -> %c (char)\n", i, *(char *)memory);
            } else if (i == 4 && flags[4]) {
                if (flags[5] && flags[6] && flags[7]) {
                    printf("%d -> %d (int)\n", i, *(int *)((char *)memory + 4));
                } else {
                    printf("%d -> %.2f (float)\n", i, *(float *)((char *)memory + 4));
                }
            }
        }
    }
    printf("-------------------------\n");
}

void remove_element(int *flags) {
    int index;
    printf("Enter the index value to be deleted: ");
    scanf("%d", &index);

    if (index >= 0 && index < SIZE && flags[index]) {
        flags[index] = 0;
        printf("Index %d successfully deleted.\n", index);
    } else {
        printf("Invalid index or index already empty.\n");
    }
}
