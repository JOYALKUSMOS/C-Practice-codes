#include <stdio.h>

int fragments(int, int *[]);

int main()
{
    
}