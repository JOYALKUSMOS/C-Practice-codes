#include <stdio.h>
#include <stdlib.h>

int matrix_mul(int **, int, int, int **, int, int, int **, int, int);

int main()
{
    int **mat_a, **mat_b, **result;
    
}