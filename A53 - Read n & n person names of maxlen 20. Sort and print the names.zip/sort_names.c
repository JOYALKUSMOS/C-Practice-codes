#include <stdio.h>

void sort_names(char (*)[20], int);

int main()
{
    __fpurge(stdout);
}