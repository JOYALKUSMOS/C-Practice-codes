#include <stdio.h>

int is_prime(int);

int main()
{
    return 0;
}