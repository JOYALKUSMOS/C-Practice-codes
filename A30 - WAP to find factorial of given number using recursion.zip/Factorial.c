#include <stdio.h>

int main()
{
    static int num;
    static unsigned long long int fact = 1;
    
    main();
}