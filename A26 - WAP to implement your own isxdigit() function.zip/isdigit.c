#include <stdio.h>

int is_xdigit(int);

int main()
{
    char ch;
    short ret;
    
    printf("Enter a character: ");
    scanf("%c", &ch);
    
    ret = is_xdigit(ch);
    
    /* Based on the return value of the function print the message */
    
    
    return 0;
}

