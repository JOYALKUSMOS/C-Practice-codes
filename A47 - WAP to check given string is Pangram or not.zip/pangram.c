#include <stdio.h>

int pangram(char []);

int main()
{
    
}