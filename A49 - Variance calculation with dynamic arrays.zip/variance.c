#include <stdio.h>

float variance(int *, int);

int main()
{
    
}